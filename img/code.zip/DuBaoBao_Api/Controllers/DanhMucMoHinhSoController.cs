using DuBaoBao.Application.DTO;
using DuBaoBao.Application.DanhMucMoHinhSo.Commands;
using DuBaoBao.Application.DanhMucMoHinhSo.Queries;
using Microsoft.AspNetCore.Mvc;
using SharedKernel.Api;
using SharedKernel.Application.Exceptions;
using System.Text.Json;

namespace DuBaoBao.Api.Controllers
{
    [Route("api/danh-muc")]
    [ApiController]
    public class DanhMucMoHinhSoController : BaseApiController
    {
        #region get danh sach du lieu form
        /// <summary>
        /// Lay danh sach
        /// </summary>
        /// <param name="page">default = 1, page hien thi</param>
        /// <param name="page_size"> so dong tra ra trong 1 page </param>
        /// <param name="sort">  sort = { field:value }</param>
        /// <param name="filter"> filter = { field:value }</param>
        /// <param name="search">Tu khoa tim kiem </param>
        /// <returns></returns>
        [HttpGet]
        [Route("")]
        public async Task<ActionResult> GetAll(DanhMucMoHinhSoGetAllQuery query)
        {
            var result = await Mediator.Send(query);
            return Ok(result);
        }
        #endregion

        #region Create
        /// <summary>
        /// Chinh sua ban ghi
        /// </summary>
        /// <param name="obj">object dang json chua du lieu them moi</param>
        /// <returns></returns>
        [HttpPost("")]
        public async Task<ActionResult> Create(DanhMucMoHinhSoCreateCommand request)
        {
            try
            {
                var result = await Mediator.Send(request);
                return Created("", result);
            }
            catch (Exception ex)
            {
                var err = ErrorCtr.ExtractErrorInfo(ex);
                return StatusCode(Convert.ToInt32(err.errorCode), err.errors);
            }
        }
        #endregion

        #region Update
        /// <summary>
        /// Chinh sua ban ghi
        /// </summary>
        /// <param name="obj">object dang json chua du lieu chinh sua</param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public async Task<ActionResult> Update(DanhMucMoHinhSoUpdateCommand request)
        {
            try
            {
                var result = await Mediator.Send(request);
                return Created("", result);
            }
            catch (Exception ex)
            {
                var err = ErrorCtr.ExtractErrorInfo(ex);
                return StatusCode(Convert.ToInt32(err.errorCode), err.errors);
            }
        }
        #endregion

        #region Delete
        /// <summary>
        /// Xoa ban ghi
        /// </summary>
        /// <param name="obj">object dang json chua du lieu xoa</param>
        /// <returns></returns>
        [HttpDelete]
        [Route("{id}/{ids}")]
        public async Task<ActionResult> Delete([FromRoute] DanhMucMoHinhSoDeleteCommand request)
        {
            try
            {
                if (request.ids.Count > 0)
                {
                    var result = new DanhMucMoHinhSoDto { };
                    var ids = request.ids.ToList();
                    request.ids.Clear();
                    foreach (var x in ids)
                    {
                        request.id = x;
                        result = await Mediator.Send(request);
                    }
                    return Created("", result);
                }
                else
                {
                    var result = await Mediator.Send(request);
                    return Created("", result);
                }
            }
            catch (Exception ex)
            {
                var err = ErrorCtr.ExtractErrorInfo(ex);
                return StatusCode(Convert.ToInt32(err.errorCode), err.errors);
            }
        }
        #endregion

        #region get by id
        /// <summary>
        /// GetById
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("{id}/get-chi-tiet")]
        public async Task<ActionResult> GetById([FromRoute] DanhMucMoHinhSoGetByIdQuery query)
        {
            var result = await Mediator.Send(query);
            return Ok(result);
        }
        #endregion
    }
}