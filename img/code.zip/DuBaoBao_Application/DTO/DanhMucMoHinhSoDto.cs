using System;
using DuBaoBao.Domain.Entities;
using AutoMapper;
using SharedKernel.Application.DTO;
using SharedKernel.Domain.Entities;

namespace DuBaoBao.Application.DTO;

public class DanhMucMoHinhSoDto : BaseAuditableDto
{

}

public class DanhMucMoHinhSoProfile : Profile
{
    public DanhMucMoHinhSoProfile()
    {
        CreateMap<danh_muc, DanhMucMoHinhSoDto>() // MAP SPECIAL, RELATIONSHIP
           .IncludeBase<BaseAuditableEntity, BaseAuditableDto>()
           //.ForMember(x => x.thoi_diem_qt, otp => otp.MapFrom(z => z.thoi_diem_qt))
           .IncludeAllDerived();
        CreateMap<DanhMucMoHinhSoDto, danh_muc>()
           .IncludeBase<BaseAuditableDto, BaseAuditableEntity>()
           //.ForMember(x => x.thoi_diem_qt, otp => otp.MapFrom(z => z.thoi_diem_qt))
           .IncludeAllDerived();
    }
}