using AutoMapper;
using DuBaoBao.Application.DTO;
using DuBaoBao.Application.Interfaces;
using DuBaoBao.Domain.Entities;
using MediatR;
using SharedKernel.Application.Queries;

namespace DuBaoBao.Application.DanhMucMoHinhSo.Queries;

public record DanhMucMoHinhSoGetByIdQuery : GetByIdQuery, IRequest<DanhMucMoHinhSoDto> { }

public class DanhMucMoHinhSoGetByIdQueryHandler :
    GetByIdQueryHandler<IDuBaoBaoDbContext, danh_muc>,
    IRequestHandler<DanhMucMoHinhSoGetByIdQuery, DanhMucMoHinhSoDto>
{
    public DanhMucMoHinhSoGetByIdQueryHandler(IDuBaoBaoDbContext context, IMapper mapper, IMediator mediator) : base(context, mapper, mediator) { }

    public Task<DanhMucMoHinhSoDto> Handle(DanhMucMoHinhSoGetByIdQuery request, CancellationToken cancellationToken)
    {
        return Handle<DanhMucMoHinhSoDto>(request, cancellationToken);
    }
}