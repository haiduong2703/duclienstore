using AutoMapper;
using DuBaoBao.Application.DTO;
using DuBaoBao.Application.Interfaces;
using DuBaoBao.Domain.Entities;
using MediatR;
using SharedKernel.Application.Queries;

namespace DuBaoBao.Application.DanhMucMoHinhSo.Queries;

public record DanhMucMoHinhSoGetAllQuery : GetAllQuery, IRequest<ResponeListDto<DanhMucMoHinhSoDto>>
{
      //[FromQuery] [FromRoute]
    //public string ma { get; set; }
}
public class DanhMucMoHinhSoGetAllQueryHandler :
    GetAllQueryHandler<IDuBaoBaoDbContext, danh_muc>,
    IRequestHandler<DanhMucMoHinhSoGetAllQuery, ResponeListDto<DanhMucMoHinhSoDto>>
{
    public DanhMucMoHinhSoGetAllQueryHandler(IDuBaoBaoDbContext context, IMapper mapper, IMediator mediator) : base(context, mapper, mediator)
    {
    }
    public Task<ResponeListDto<DanhMucMoHinhSoDto>> Handle(DanhMucMoHinhSoGetAllQuery request, CancellationToken cancellationToken)
    {
        return this.Handle<DanhMucMoHinhSoDto>(request, cancellationToken);
    }
    protected override IQueryable<danh_muc> QueryBuilder(IQueryable<danh_muc> query, dynamic filter, string search, GetAllQuery request)
    {
        String txt_search = search;
        if (!string.IsNullOrEmpty(txt_search))
        {
            txt_search = txt_search.ToLower().Trim();
            //query = query.Where(x => x.ten.ToLower().Contains(txt_search) || x.ten.ToLower().Contains(txt_search));
        }

        if (filter is null)
            return query;

        //FILTER DYNAMIC HERE
        /*
 {
  "trang_thai": {
    "value": false,
    "label": "Không sử dụng"
  },
  "ngay_Tao": [
    "2024-09-18",
    "2024-10-15"
  ]
}
         */
        try
        {
            /*
            if (!string.IsNullOrEmpty(Convert.ToString(filter.trang_thai)))
            {
                var trang_thai = filter.trang_thai;
                if (!string.IsNullOrEmpty(Convert.ToString(trang_thai.value)))
                {
                    bool str_trang_thai = Convert.ToBoolean(trang_thai.value);
                    query = query.Where(x => x.trang_thai == str_trang_thai);
                }
            }
            if (!string.IsNullOrEmpty(filter.ngay_Tao))
            {
                var ngay_tao = filter.ngay_Tao;
                string str_ngay_tao = Convert.ToString(ngay_tao);
                if (Convert.ToString(ngay_tao).IndexOf("[") >= 0)
                {
                    if (str_ngay_tao.IndexOf(",") > 0)
                    {
                        DateTime fromDate = DateTime.Parse(Convert.ToString(ngay_tao[0].Value));
                        DateTime toDate = DateTime.Parse(Convert.ToString(ngay_tao[1].Value)).AddDays(1);
                        query = query.Where(x => x.ngay_tao >= fromDate && x.ngay_tao < toDate);
                    }
                    else
                    {
                        DateTime toDate = DateTime.Parse(Convert.ToString(ngay_tao[0].Value));
                        query = query.Where(x => x.ngay_tao == toDate);
                    }
                }
                else
                {
                    DateTime toDate = DateTime.Parse(str_ngay_tao);
                    query = query.Where(x => x.ngay_tao == toDate);
                }
            }
            */

        }
        catch { }

        return query;
    }
}