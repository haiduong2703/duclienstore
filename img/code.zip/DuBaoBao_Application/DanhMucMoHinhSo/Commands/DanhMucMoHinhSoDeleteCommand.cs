using AutoMapper;
using DuBaoBao.Application.DTO;
using DuBaoBao.Application.Interfaces;
using DuBaoBao.Domain.Entities;
using MediatR;
using SharedKernel.Application.Commands;

namespace DuBaoBao.Application.DanhMucMoHinhSo.Commands;

public record DanhMucMoHinhSoDeleteCommand : DeleteCommand, IRequest<DanhMucMoHinhSoDto> { }
public class DanhMucMoHinhSoDeleteCommandHandler : DeleteCommandHandler<IDuBaoBaoDbContext, danh_muc>, IRequestHandler<DanhMucMoHinhSoDeleteCommand, DanhMucMoHinhSoDto>
{
    public DanhMucMoHinhSoDeleteCommandHandler(IDuBaoBaoDbContext context, IMapper mapper, IMediator mediator) : base(context, mapper, mediator)
    {
    }

    public async Task<DanhMucMoHinhSoDto> Handle(DanhMucMoHinhSoDeleteCommand request, CancellationToken cancellationToken)
    {
        var entity = await Handle((DeleteCommand)request, cancellationToken);
        return entity == null ? null : _mapper.Map<danh_muc, DanhMucMoHinhSoDto>(entity);
    }
}