using DuBaoBao.Application.Interfaces;
using DuBaoBao.Domain.Entities;
using AutoMapper;
using FluentValidation;
using MediatR;
using SharedKernel.Application.Exceptions;
using SharedKernel.Application.Commands;
using DuBaoBao.Application.DTO;

namespace DuBaoBao.Application.DanhMucMoHinhSo.Commands;

public record DanhMucMoHinhSoUpdateCommand : UpdateCommand<DanhMucMoHinhSoDto>, IRequest<DanhMucMoHinhSoDto> { }
public class DanhMucMoHinhSoUpdateCommandHandler : UpdateCommandHandler<IDuBaoBaoDbContext, danh_muc>, IRequestHandler<DanhMucMoHinhSoUpdateCommand, DanhMucMoHinhSoDto>
{
    public DanhMucMoHinhSoUpdateCommandHandler(IDuBaoBaoDbContext context, IMapper mapper, IMediator mediator) : base(context, mapper,mediator)
    {
    }

    public Task<DanhMucMoHinhSoDto> Handle(DanhMucMoHinhSoUpdateCommand request, CancellationToken cancellationToken)
    {
        return Handle<DanhMucMoHinhSoDto>(request, cancellationToken);
    }
}

public class DanhMucMoHinhSoUpdateCommandValidator : AbstractValidator<DanhMucMoHinhSoUpdateCommand>
{
    protected readonly IDuBaoBaoDbContext _context;
    public DanhMucMoHinhSoUpdateCommandValidator(IDuBaoBaoDbContext context)
    {
        _context = context;
        RuleFor(f => f.data);
    }
}