using DuBaoBao.Application.Interfaces;
using DuBaoBao.Domain.Entities;
using AutoMapper;
using FluentValidation;
using MediatR;
using SharedKernel.Application.Exceptions;
using SharedKernel.Application.Utils;
using SharedKernel.Application.Commands;
using DuBaoBao.Application.DTO;

namespace DuBaoBao.Application.DanhMucMoHinhSo.Commands;

public record DanhMucMoHinhSoCreateCommand : CreateCommand<DanhMucMoHinhSoDto>, IRequest<DanhMucMoHinhSoDto> { }
public class DanhMucMoHinhSoCreateCommandHandler : CreateCommandHandler<IDuBaoBaoDbContext, danh_muc>, IRequestHandler<DanhMucMoHinhSoCreateCommand, DanhMucMoHinhSoDto>
{
    public DanhMucMoHinhSoCreateCommandHandler(IDuBaoBaoDbContext context, IMapper mapper, IMediator mediator) : base(context, mapper,mediator)
    {
    }

    public Task<DanhMucMoHinhSoDto> Handle(DanhMucMoHinhSoCreateCommand request, CancellationToken cancellationToken)
    {
        if (request.data.id == Guid.Empty) request.data.id = Guid.NewGuid();
        return Handle<DanhMucMoHinhSoDto>(request, cancellationToken);
    }
}

public class DanhMucMoHinhSoCreateCommandValidator : AbstractValidator<DanhMucMoHinhSoCreateCommand>
{
    protected readonly IDuBaoBaoDbContext _context;
    public DanhMucMoHinhSoCreateCommandValidator(IDuBaoBaoDbContext context)
    {
        _context = context;
        RuleFor(f => f.data);
    }
}